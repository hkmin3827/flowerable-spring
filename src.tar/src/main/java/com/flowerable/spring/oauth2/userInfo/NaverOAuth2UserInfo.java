package com.flowerable.spring.oauth2.userInfo;

import com.flowerable.spring.constant.auth.Provider;

import java.util.Map;

public class NaverOAuth2UserInfo implements OAuth2UserInfo{
    private final Map<String, Object> attributes;

    public NaverOAuth2UserInfo(Map<String, Object> attributes) {
        Object response = attributes.get("response");

        if (!(response instanceof Map)) {
            throw new IllegalArgumentException("Invalid Naver OAuth response");
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> castedResponse = (Map<String, Object>) response;
        this.attributes = castedResponse;
    }
    @Override
    public Provider getProvider() {
        return Provider.NAVER;
    }

    @Override
    public String getProviderId() {
        return attributes.get("id").toString(); // 네이버 고유 ID
    }

    @Override
    public String getEmail() {
        return (String) attributes.get("email");
    }

    @Override
    public String getName() {
        return (String) attributes.get("name");
    }
}
