package com.flowerable.spring.service.payment;

import com.flowerable.spring.constant.common.ErrorCode;
import com.flowerable.spring.constant.notification.NotificationReceiverType;
import com.flowerable.spring.constant.notification.NotificationType;
import com.flowerable.spring.constant.order.OrderCancelReason;
import com.flowerable.spring.constant.payment.PaymentStatus;
import com.flowerable.spring.dto.notification.NotificationCreateReq;
import com.flowerable.spring.dto.payment.PaymentConfirmReq;
import com.flowerable.spring.entity.order.OrderRequest;
import com.flowerable.spring.entity.payment.Payment;
import com.flowerable.spring.exception.CustomException;
import com.flowerable.spring.exception.OrderNotFoundException;
import com.flowerable.spring.repository.OrderRequestRepository;
import com.flowerable.spring.repository.PaymentRepository;
import com.flowerable.spring.service.notification.NotificationService;
import com.google.common.net.HttpHeaders;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Base64;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class PaymentService {

    @Value("${toss.secret-key}")
    private String secretKey;

    private final PaymentRepository paymentRepository;
    private final OrderRequestRepository orderRequestRepository;
    private final NotificationService notificationService;


    @Transactional
    public Long confirm(PaymentConfirmReq req) {

        OrderRequest order = orderRequestRepository.findByOrderNumber(req.getOrderId())
                .orElseThrow(OrderNotFoundException::new);

        if (!order.getTotalPrice().equals(req.getAmount())) {
            throw new RuntimeException("금액 불일치");
        }

        if (req.getPaymentKey() == null)
            throw new CustomException(ErrorCode.PAYMENT_KEY_NOT_FILLED);

        if(order.isPaid()) {
            throw new CustomException(ErrorCode.ORDER_ALREADY_PAID);
        }

        Payment payment = Payment.createReady(order, req.getAmount());
        paymentRepository.save(payment);

        try {
            WebClient webClient = WebClient.builder()
                    .baseUrl("https://api.tosspayments.com")
                    .defaultHeader(HttpHeaders.AUTHORIZATION,
                            "Basic " + Base64.getEncoder()
                                    .encodeToString((secretKey + ":").getBytes()))
                    .build();

            webClient.post()
                    .uri("/v1/payments/confirm")
                    .bodyValue(req)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            payment.markDone(req.getPaymentKey());

            order.markRequested(); // 결제 성공 → 샵 전달

            String content = order.getMessage() == null
                    ? "주문 확인 후 접수 또는 취소해주세요."
                    : "주문 확인 후 접수 또는 취소해주세요. (요청 사항 : " + order.getMessage()+ ")";
            notifyShop(order, order.getShop().getId(), NotificationType.ORDER_CREATED, content);

            return order.getId();
        } catch(Exception e) {
            saveFailed(payment, e.getMessage());

            throw e;
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void saveFailed(Payment payment, String reason) {
        payment.markFailed(reason);
    }

    /**
     * Toss 결제 취소 요청
     * 실패 시 RuntimeException 발생 → 상위 트랜잭션 롤백
     */
    public void cancelPayment(OrderRequest order, OrderCancelReason cancelReason) {

        Payment payment = paymentRepository
                .findTopByOrderIdAndStatusOrderByCreatedAtDesc(
                        order.getId(),
                        PaymentStatus.DONE
                )
                .orElseThrow(() -> new CustomException(ErrorCode.PAYMENT_NOT_FOUND));

        try {

            WebClient webClient = WebClient.builder()
                    .baseUrl("https://api.tosspayments.com")
                    .defaultHeader(org.springframework.http.HttpHeaders.AUTHORIZATION,
                            "Basic " + Base64.getEncoder()
                                    .encodeToString((secretKey + ":").getBytes()))
                    .build();

            webClient.post()
                    .uri("/v1/payments/" + payment.getPaymentKey() + "/cancel")
                    .bodyValue(Map.of("cancelReason", cancelReason.getDescription()))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            payment.markCanceled(cancelReason);

        } catch (WebClientResponseException e) {

            if (e.getResponseBodyAsString().contains("ALREADY_CANCELED_PAYMENT")) {
                payment.markCanceled(cancelReason); // DB 동기화
                return;
            }
            // Toss 취소 실패 → 롤백 유도
            System.out.println("status = " + e.getStatusCode());
            System.out.println("body = " + e.getResponseBodyAsString());
            throw new CustomException(ErrorCode.PAYMENT_CANCEL_FAILED);        }
    }

    private void notifyShop(OrderRequest order, Long receiverId, NotificationType type, String content) {
        notificationService.createNotification(
                new NotificationCreateReq(
                        NotificationReceiverType.SHOP,
                        receiverId,
                        type,
                        order.getOrderNumber() + " : " + type.getTitle(),
                        content,
                        order.getId()
                )
        );
    }

}
