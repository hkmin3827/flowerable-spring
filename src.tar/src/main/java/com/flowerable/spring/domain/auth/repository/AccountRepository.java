package com.flowerable.spring.domain.auth.repository;

import com.flowerable.spring.domain.auth.constant.Provider;
import com.flowerable.spring.domain.auth.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Optional<Account> findByEmail(String email);

    Optional<Account> findByEmailAndDeletedAtIsNull(String email);

    boolean existsByEmail(String email);

    Optional<Account> findByProviderAndProviderIdAndDeletedAtIsNull(Provider provider, String providerId);

    boolean existsByEmailAndDeletedAtIsNull(String email);

    boolean existsByTelnumAndDeletedAtIsNull(String telnum);

}
