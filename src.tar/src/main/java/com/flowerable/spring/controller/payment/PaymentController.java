package com.flowerable.spring.controller.payment;


import com.flowerable.spring.dto.payment.PaymentConfirmReq;
import com.flowerable.spring.service.payment.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/payments")
public class PaymentController {
    private final PaymentService paymentService;

    @PostMapping("/confirm")
    public ResponseEntity<?> confirm(@RequestBody PaymentConfirmReq req) {
        paymentService.confirm(req);
        return ResponseEntity.ok().build();
    }}
